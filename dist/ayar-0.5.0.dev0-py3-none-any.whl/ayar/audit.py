"""The finding audit: does the user's result survive removing the flagged units?

The user's finding is any function ``f(bundle) -> float | dict[str, float]``.
For each detector that raised flags, ayar removes the implicated units, recomputes
the finding, and compares the change with *random-drop controls*: the same number
of unflagged units removed at random. A change is only blamed on the artifact if
it is larger than what dropping arbitrary units does.
"""

from __future__ import annotations

import importlib
import importlib.util
import math
import sys
from pathlib import Path
from dataclasses import dataclass, field
from typing import Any, Callable

import numpy as np

from .bundle import Bundle
from .config import Thresholds
from .flags import AuditRow, Flag

FindingFn = Callable[[Bundle], Any]


@dataclass
class Action:
    """How the audit neutralises flags: units to remove, (keep, absorb) pairs to merge,
    and units to restrict to epochs (``{unit: [(start, stop), ...]}``)."""

    removes: set[int] = field(default_factory=set)
    merges: list[tuple[int, int]] = field(default_factory=list)
    restricts: dict[int, list[tuple[float, float]]] = field(default_factory=dict)

    @property
    def size(self) -> int:
        return len(self.removes) + len(self.merges) + len(self.restricts)

    @property
    def units(self) -> set[int]:
        return set(self.removes) | {u for p in self.merges for u in p} | set(self.restricts)

    def describe(self) -> str:
        parts = []
        if self.merges:
            parts.append(f"merge {len(self.merges)}")
        if self.restricts:
            parts.append(f"restrict {len(self.restricts)}")
        if self.removes:
            parts.append(f"remove {len(self.removes)}")
        return ", ".join(parts)

    def apply(self, bundle: Bundle, dedupe_s: float) -> Bundle:
        b = bundle.merge(self.merges, dedupe_s) if self.merges else bundle
        present = set(int(u) for u in b.unit_ids)
        if self.restricts:
            b = b.restrict({u: ep for u, ep in self.restricts.items() if u in present and u not in self.removes})
        return b.without(self.removes & present)

    def __or__(self, other: "Action") -> "Action":
        return Action(self.removes | other.removes, self.merges + other.merges,
                      {**self.restricts, **other.restricts})


def action_for(flag: Flag) -> Action:
    """Merge for DUPLICATE/SPLIT, otherwise remove (the second unit of a pair, or the unit)."""
    from .detectors import REGISTRY

    kind = getattr(REGISTRY.get(flag.code), "ACTION", "remove")
    if kind == "restrict":
        epochs = flag.evidence.get("stable_epochs")
        if epochs:
            return Action(restricts={int(flag.units[0]): [tuple(e) for e in epochs]})
        return Action(removes={int(u) for u in flag.units})  # no stable epoch long enough
    if kind == "merge" and len(flag.units) >= 2:
        return Action(merges=[(int(flag.units[0]), int(flag.units[1]))])
    if len(flag.units) >= 2:
        return Action(removes={int(flag.units[1])})
    return Action(removes={int(u) for u in flag.units})


def units_to_drop(flag: Flag) -> set[int]:
    """Units a flag implicates for removal (kept for backwards compatibility)."""
    a = action_for(flag)
    return set(a.removes) | {p[1] for p in a.merges} | set(a.restricts)


def _random_action(template: Action, pool: np.ndarray, bundle: Bundle, rng,
                   depth: dict[int, float | None] | None = None) -> Action | None:
    """Same operations as ``template`` on random unflagged units.

    Merges pair a random unit with its nearest unflagged neighbour; restrictions keep a
    random contiguous block as long as the flagged unit's stable epoch.
    """
    need = len(template.removes) + 2 * len(template.merges) + len(template.restricts)
    if pool.size < need:
        return None
    avail = list(rng.permutation(pool))
    merges = []
    if depth is None and bundle.has_depths and template.merges:
        depth = {int(u): bundle.depth(int(u)) for u in pool}
    for _ in template.merges:
        a = int(avail.pop())
        if depth is not None and depth[a] is not None:
            b = min(avail, key=lambda v: abs((depth[int(v)] or 0.0) - depth[a]))
            avail.remove(b)
        else:
            b = avail.pop()
        merges.append((a, int(b)))
    restricts = {}
    T = bundle.duration
    for ep in template.restricts.values():
        length = float(sum(b - a for a, b in ep))
        start = float(rng.uniform(0, max(T - length, 0.0)))
        restricts[int(avail.pop())] = [(start, start + length)]
    removes = {int(avail.pop()) for _ in template.removes}
    return Action(removes, merges, restricts)


def call_finding(fn: FindingFn, bundle: Bundle) -> dict[str, float]:
    out = fn(bundle)
    if isinstance(out, dict):
        items = out.items()
    else:
        items = [("value", out)]
    res: dict[str, float] = {}
    for k, v in items:
        try:
            res[str(k)] = float(v)
        except (TypeError, ValueError):
            raise TypeError(
                f"finding must return a number or a dict of numbers; {k!r} is {type(v).__name__}"
            ) from None
    return res


def _rel(new: float, base: float) -> float:
    if not (math.isfinite(new) and math.isfinite(base)):
        return math.inf
    return abs(new - base) / max(abs(base), 1e-12)


def _flipped(new: float, base: float) -> bool:
    return base != 0 and new != 0 and math.copysign(1, new) != math.copysign(1, base)


def _verdict(rel, new, base, ctrl_q, flip_rate, th, controlled: bool = True) -> str:
    if rel < th.audit_robust:
        return "robust"
    if not controlled:
        # without random controls there is no way to tell an artifact from removing many units
        return "uncontrolled"
    beyond = ctrl_q is None or rel > ctrl_q
    if _flipped(new, base) and (flip_rate is None or flip_rate < 1 - th.audit_control_quantile):
        return "flipped"
    if not beyond:
        return "nonspecific"
    if rel >= th.audit_sensitive:
        return "sensitive"
    return "shifted"


def audit(
    bundle: Bundle,
    finding: FindingFn,
    flags: list[Flag],
    th: Thresholds,
) -> tuple[dict[str, float], list[AuditRow]]:
    baseline = call_finding(finding, bundle)
    # merged copies may be time-shifted by up to dup_max_lag: count them once
    dedupe = (th.dup_window_ms + th.dup_max_lag_ms) / 1000.0

    groups: dict[str, Action] = {}
    for f in flags:
        groups[f.code] = groups.get(f.code, Action()) | action_for(f)
    if len(groups) > 1:
        total = Action()
        for a in groups.values():
            total = total | a
        groups["ALL_FLAGS"] = total

    flagged_any = set().union(*(a.units for a in groups.values())) if groups else set()
    rng = np.random.default_rng(th.audit_seed)
    all_units = [int(u) for u in bundle.unit_ids]
    depth = {u: bundle.depth(u) for u in all_units} if bundle.has_depths else None

    rows: list[AuditRow] = []
    for name, action in groups.items():
        k = action.size
        try:
            value = call_finding(finding, action.apply(bundle, dedupe))
        except Exception as e:  # the user's function may not cope with fewer units
            for key, base in baseline.items():
                rows.append(AuditRow(key, name, k, base, None, None, None, None, "failed",
                                     f"finding raised {type(e).__name__}: {e}", action.describe()))
            continue

        # controls come from unflagged units; only when there are too few (raw sortings where most
        # units are flagged) does a single detector's control also draw on units flagged by *other*
        # detectors, which are not the artifact under test. ALL_FLAGS can only use unflagged units.
        need = len(action.removes) + 2 * len(action.merges) + len(action.restricts)
        pool = np.array([u for u in all_units if u not in flagged_any])
        if pool.size < need and name != "ALL_FLAGS":
            pool = np.array([u for u in all_units if u not in action.units])
        controls: list[dict[str, float]] = []
        note = ""
        # a repair that moves no key beyond audit_robust is robust whatever the controls show,
        # so the controls are drawn (keeping the random stream, and so every other repair's
        # controls, unchanged) but the finding is not re-run on them
        all_robust = all(_rel(value.get(key, math.nan), base) < th.audit_robust for key, base in baseline.items())
        skip = all_robust and not th.audit_controls_when_robust
        if th.audit_controls > 0:
            for _ in range(th.audit_controls):
                ctrl = _random_action(action, pool, bundle, rng, depth)
                if ctrl is None:
                    note = f"no random controls: only {pool.size} unflagged units for {action.describe()}"
                    break
                if skip:
                    continue
                try:
                    controls.append(call_finding(finding, ctrl.apply(bundle, dedupe)))
                except Exception:
                    pass
            if skip and not note:
                note = f"random controls not run: no change reaches audit_robust ({th.audit_robust:g})"

        for key, base in baseline.items():
            new = value.get(key, math.nan)
            rel = _rel(new, base)
            ctrl_rel = [_rel(c[key], base) for c in controls if key in c]
            ctrl_q = float(np.quantile(ctrl_rel, th.audit_control_quantile)) if ctrl_rel else None
            flip_rate = (
                float(np.mean([_flipped(c[key], base) for c in controls if key in c]))
                if ctrl_rel else None
            )
            rows.append(
                AuditRow(
                    key=key,
                    ablation=name,
                    n_dropped=k,
                    baseline=base,
                    value=new,
                    rel_change=rel,
                    control_q=ctrl_q,
                    control_flip_rate=flip_rate,
                    verdict=_verdict(rel, new, base, ctrl_q, flip_rate, th,
                                     controlled=bool(ctrl_rel) or th.audit_controls == 0),
                    note=note,
                    action=action.describe(),
                )
            )
    return baseline, rows


def load_finding(spec: str) -> tuple[str, FindingFn]:
    """Resolve ``path/to/file.py:func`` or ``package.module:func``."""
    if ":" not in spec:
        raise ValueError(f"finding must look like file.py:func or module:func, got {spec!r}")
    target, func = spec.rsplit(":", 1)
    if target.endswith(".py") or Path(target).exists():
        path = Path(target).resolve()
        if not path.exists():
            raise FileNotFoundError(path)
        mod_name = f"_ayar_finding_{path.stem}"
        spec_obj = importlib.util.spec_from_file_location(mod_name, path)
        if spec_obj is None or spec_obj.loader is None:
            raise ImportError(f"cannot import {path}")
        module = importlib.util.module_from_spec(spec_obj)
        sys.modules[mod_name] = module
        spec_obj.loader.exec_module(module)
    else:
        module = importlib.import_module(target)
    fn = getattr(module, func, None)
    if not callable(fn):
        raise AttributeError(f"{target} has no callable {func!r}")
    return f"{Path(target).name if target.endswith('.py') else target}:{func}", fn
